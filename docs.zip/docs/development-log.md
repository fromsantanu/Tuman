# Development log

## Phase 00 — Project specification and architecture

**Date:** 2026-09-01  
**Status:** Complete

### Completed work

- Inspected the repository and confirmed it is a new Tuman project.
- Recorded the proposed simple modular PHP project layout.
- Defined the application layers, roles, access boundaries, and security baseline.
- Produced an initial entity/relationship and financial-history design.
- Documented key decisions and decisions deliberately deferred to later phases.
- Added a Phase 00 README and documentation set.
- Established `tmn_` as the required prefix for all current and future database tables.

### Not implemented

- No PHP application pages or services.
- No database or migration files.
- No authentication, user management, or public website.
- No environment file containing secrets.

### Next recommended phase

Phase 03 — Authentication and authorization.

## Phase 02 — MySQL database

**Date:** 2026-09-02  
**Status:** Completed with environment issue

### Completed work

- Added `database/schema.sql` with 14 `tmn_` tables, foreign keys, indexes, unique keys, `utf8mb4`, and financial constraints.
- Added `database/seed.sql` with fictional development data and documented development-only credentials.
- Added `.env.example`, environment loading, a reusable PDO connection helper, and a connection check.
- Updated database installation and design documentation.

### Environment issue

The local MySQL service is running, but it rejects the standard blank-password root account. Schema execution and live connection verification await valid local credentials in an uncommitted `.env` file. The code reports this safely without exposing connection details.

## Phase 03 — Authentication and authorization

**Date:** 2026-09-02  
**Status:** Completed with environment limitation

### Implemented

- Added reusable secure session, CSRF, authentication, logout, current-user, and role-guard helpers.
- Added a CSRF-protected login form and POST-only CSRF-protected logout endpoint.
- Used the existing PDO helper and parameterized lookup of `tmn_users`; successful logins verify PHP password hashes, reject inactive accounts, regenerate the session ID, and update `last_login_at`.
- Added minimal role-protected Administrator, Teacher, and Student placeholders. They contain no business functionality.

### Tests and limitation

- PHP syntax checks and helper-level CSRF/session-regeneration/logout tests pass.
- Live login, user status, last-login, database query, and browser redirect tests remain blocked until valid MySQL credentials are placed in the uncommitted `.env` file.

### Next recommended phase

Phase 04 — Public website.
