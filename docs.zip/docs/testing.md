# Testing approach

## Current phase

Phase 02 added PHP configuration and SQL source files. PHP syntax was checked successfully for the environment loader, PDO helper, and connection test. The schema contains 14 tables and the naming check confirmed they all use `tmn_`.

The PDO test correctly returns a safe configuration error when `.env` is absent. On this machine, the running MySQL server rejects the default XAMPP `root`/blank-password credentials, so applying and integration-testing the SQL requires valid local MySQL credentials. No credentials were guessed or added to source control.

## Phase 03 results

| Test | Result | Notes |
| --- | --- | --- |
| PHP syntax for authentication files and protected placeholders | PASS | `php -l` completed without errors. |
| CSRF valid and invalid token validation | PASS | Covered by `tests/auth_helpers.php`. |
| Session ID regeneration after login | PASS | Covered by `tests/auth_helpers.php`. |
| Session identity setup and logout clearing | PASS | Covered by `tests/auth_helpers.php`. |
| Login with valid seeded account | BLOCKED | Requires valid local database credentials in `.env`. |
| Wrong/unknown/inactive account rejection | BLOCKED | Requires valid local database credentials and seed schema. |
| Last-login update | BLOCKED | Requires valid local database credentials and seed schema. |
| Browser redirect/direct URL/cross-role tests | BLOCKED | Requires a configured database and local web request session. |
| SQL injection login input | BLOCKED | Query is parameterized in code; live verification awaits database access. |

The CLI helper test sets its session location to the system temporary folder because this workspace cannot write to XAMPP's web-server session folder. This is a test-environment adjustment only; it does not alter application session settings.

## Testing strategy for later phases

Each phase will record the commands and checks actually performed. Testing will cover the following categories when relevant:

- **Normal flows:** valid inputs and successful expected outcomes.
- **Validation failures:** missing, malformed, or out-of-range values.
- **Authentication:** valid login, incorrect password, inactive user, logout, and protected URL access.
- **Authorization:** administrator/teacher/student boundaries, including attempts to manipulate identifiers.
- **Security:** CSRF rejection, output escaping, session handling, and parameterized database queries.
- **Financial integrity:** rate history, invoice totals, payment totals, rejected overpayment, and void/cancellation behavior.
- **Regression:** existing functionality remains usable after a later phase is added.

## Initial high-risk acceptance cases

| Area | Expected result |
| --- | --- |
| Inactive account login | Rejected without revealing sensitive details. |
| Teacher A requests Teacher B's student | Rejected by an ownership-scoped server-side query. |
| Student changes an attendance or invoice identifier | No data belonging to another student is returned. |
| Billing-rate update | Existing invoice item rates do not change. |
| Payment exceeding outstanding balance | Rejected unless an explicit future overpayment policy enables it. |
| Invalid state-changing request without CSRF token | Rejected. |
