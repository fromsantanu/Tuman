# Tuman user manual

## Status

Tuman is in architecture planning. There are no usable application screens yet, so this is an outline for the manual that will be completed as modules are implemented.

## Planned audiences

- **Administrators:** manage accounts and system-level settings.
- **Teachers:** manage assigned students, responsibilities, attendance, billing, invoices, and payments.
- **Students:** view and update permitted profile details; view only their own attendance and financial information.

## Planned manual sections

1. Signing in and signing out
2. Administrator account management
3. Teacher student management
4. Responsibilities and attendance
5. Billing, invoices, and payments
6. Student self-service views
7. Error messages and support

Each implemented section will explain its purpose, required permissions, normal steps, validation messages, and any irreversible or historical-record behaviour.

## Signing in and out (Phase 03)

Open `/public/login.php`, enter the username and password supplied by an administrator, then select **Sign in**. Active Administrator, Teacher, and Student accounts are sent to their own protected landing pages. Those pages are temporary access-control checks, not the completed dashboards.

If the details are wrong or the account is inactive, Tuman displays the same general sign-in failure message. Use the **Sign out** button on a protected page to end the session. The sign-out action uses a protected form and cannot be performed by opening the logout URL directly.
