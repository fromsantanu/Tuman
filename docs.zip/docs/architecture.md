# Tuman architecture

## Purpose and scope

Tuman is a Tuition Management System for three roles: Administrator, Teacher, and Student. The application will be built incrementally in PHP without a large framework so that its structure remains approachable to students.

This document records the initial architectural decisions for Phase 00. It describes the intended design; it does not mean that the described modules already exist.

## Proposed project structure

```text
Tuman/
├── public/                 # Public entry pages and static web root
│   ├── index.php
│   ├── about.php
│   ├── login.php
│   └── logout.php
├── admin/                  # Administrator-only pages
├── teacher/                # Teacher-only pages
├── student/                # Student-only pages
├── config/                 # Environment loading and database configuration
├── includes/               # Small reusable helpers, guards, and layout parts
├── services/               # Reusable domain services (invoice, payment, email, PDF)
├── templates/              # Shared HTML layout and email/PDF templates
├── database/               # Versioned schema, migrations, and development seeds
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── docs/
├── tests/
├── .env.example
├── .gitignore
├── README.md
└── CHANGELOG.md
```

The directories above will be created in Phase 01 as needed. Keeping public pages separate from role-specific pages makes access boundaries visible, but every protected request must still be checked on the server.

## Application layers

1. **Pages/controllers** receive a request, require authentication and role access, validate input, and select a template.
2. **Services** contain reusable business rules that should not be copied between pages, such as invoice-total calculation and payment validation.
3. **Database access** uses PDO and parameterized SQL. Queries that access owned records must include ownership constraints.
4. **Templates** render escaped output. They never decide authorization or execute business logic.
5. **Configuration** reads environment-specific settings and is excluded from version control.

This is intentionally a small modular architecture, not a full MVC framework.

## Authentication and authorization

All users authenticate through one `tmn_users` table with a username and a PHP password hash. After a successful login, Tuman regenerates the session identifier and stores only the authenticated user's identity and role needed for access checks.

Every protected page will use a reusable authentication guard. A role guard will allow only the appropriate role. Ownership guards are additionally required for Teacher and Student data:

- Administrators may access system-wide user data within their administrative permissions.
- Teachers may access only students linked to their own teacher profile, and data belonging to those students.
- Students may access only records connected to their own student profile.

Navigation visibility is only a convenience; database queries and server-side guards enforce the actual permission boundary.

### Implemented Phase 03 flow

`public/login.php` validates its CSRF token and credentials, then uses a parameterized lookup against `tmn_users` and `password_verify()`. Only an `ACTIVE` user with one of the database roles (`ADMIN`, `TEACHER`, or `STUDENT`) can authenticate. On success, `last_login_at` is updated in UTC, the session ID is regenerated, and only the user ID and role are stored in the session. The user is then sent to the matching protected placeholder area.

`includes/auth.php` centralizes login, logout, current-user, role-home, and role-guard behaviour. `tuman_require_role()` redirects unauthenticated requests to the login page and returns HTTP 403 for an authenticated user with the wrong role. Later ownership checks will extend this layer rather than trusting request parameters.

`includes/csrf.php` creates one random token per session and uses `hash_equals()` for validation. State-changing forms must include `tuman_csrf_token()` and validate it with `tuman_require_csrf()` (or `tuman_csrf_is_valid()` when a page must re-render an error). Login and logout already follow this rule.

`includes/session.php` uses a named, strict session with HttpOnly and SameSite=Lax cookies. The Secure flag is enabled only when the request uses HTTPS, keeping local HTTP development usable. Logout clears session data, expires the browser cookie, and destroys the server-side session.

## Security baseline

- PDO prepared statements for all values originating outside trusted program code.
- `password_hash()` and `password_verify()` for passwords; passwords are never stored or logged in plain text.
- CSRF tokens on all state-changing forms.
- Output escaping in templates to reduce XSS risk.
- Server-side validation for all input and identifiers.
- Session ID regeneration after login and complete session destruction at logout.
- Friendly production error messages; technical details go to logs, not the browser.
- Secrets live in an uncommitted `.env` file, with keys documented in `.env.example`.
- Login throttling is intentionally deferred to the security-audit phase; no account or request data is yet collected for rate limiting.

## Domain services planned for later phases

The following services will be introduced only when their related phase begins:

- User and profile management
- Student enrolment/assignment
- Responsibilities management
- Attendance recording and duration calculation
- Billing-rate selection by effective date
- Invoice numbering, generation, and totals
- Payment validation and invoice-balance calculation
- Email delivery and delivery logging
- PDF invoice rendering

## Key architectural decisions before coding

1. **One teacher per student initially.** The `tmn_teacher_students` assignment table is used even though it has one active teacher per student in the first release. This retains an assignment history and leaves room for future multi-teacher support.
2. **Table naming is fixed.** Every current and future database table must begin with `tmn_`.
3. **Multiple sessions per day are allowed by design.** Attendance has its own session identifier and unique session start; the application can initially offer a simple one-session-per-date workflow while the schema does not block later expansion.
4. **Money is stored as `DECIMAL`, never float.** Calculations use deterministic two-decimal rounding rules.
5. **Financial history is immutable in effect.** Invoice items keep a snapshot of description, quantity, and rate. Rate changes therefore cannot rewrite an issued invoice.
6. **Removal is normally status-based.** Users and assignments are deactivated/ended rather than deleted where history depends on them. Financial records are retained and corrected through statuses or reversal-style records rather than casual deletion.
7. **Invoice numbers use a database-backed sequence.** A transaction will reserve a unique number; PHP must not generate invoice numbers by counting rows.

## Decisions deferred until their phases

- Exact invoice-number display format and financial-year reset policy.
- Whether teachers can edit only contact information or a larger set of student profile fields.
- Default due-date policy and discount rules.
- Initial administrator provisioning method for deployment.
- Choice of email and PDF libraries/provider, if those phases require one.
- Whether cancelled attendance sessions count as zero hours in all reports (the recommended initial rule is yes).
