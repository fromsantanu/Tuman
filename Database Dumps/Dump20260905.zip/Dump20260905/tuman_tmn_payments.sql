-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_payments`
--

DROP TABLE IF EXISTS `tmn_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint unsigned NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `payment_method` enum('CASH','UPI','BANK_TRANSFER','CARD','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('VALID','VOIDED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'VALID',
  `voided_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tmn_payments_invoice_status` (`invoice_id`,`status`),
  KEY `idx_tmn_payments_date` (`payment_date`),
  CONSTRAINT `fk_tmn_payments_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `tmn_invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_tmn_payments_amount` CHECK ((`amount` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_payments`
--

LOCK TABLES `tmn_payments` WRITE;
/*!40000 ALTER TABLE `tmn_payments` DISABLE KEYS */;
INSERT INTO `tmn_payments` VALUES (1,1,'2026-09-03',1500.00,'INR','UPI','DEMO-UPI-001','Development-only sample payment','VALID',NULL,'2026-09-02 11:21:51','2026-09-02 11:21:51'),(2,7,'2026-09-03',2500.00,'INR','CASH','TMN 2026-000003','1800 payment and 700 advance for next part','VALID',NULL,'2026-09-03 15:30:15','2026-09-03 15:30:15'),(3,2,'2026-09-03',1300.00,'INR','CASH','TMN 2026-000002','Fully paid','VALID',NULL,'2026-09-03 15:33:37','2026-09-03 15:33:37'),(4,9,'2026-09-03',2500.00,'INR','CASH','TMN 2026-000005','500 excess payment for the next month','VALID',NULL,'2026-09-03 15:58:13','2026-09-03 15:58:13'),(5,10,'2026-09-03',1500.00,'INR','CASH','TMN 2026-000006','Full payment','VALID',NULL,'2026-09-03 16:07:17','2026-09-03 16:07:17'),(6,1,'2026-09-03',4500.00,'INR','CASH','Extra received for future',NULL,'VALID',NULL,'2026-09-03 20:32:02','2026-09-03 20:32:02');
/*!40000 ALTER TABLE `tmn_payments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:44
