-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_users`
--

DROP TABLE IF EXISTS `tmn_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('ADMIN','TEACHER','STUDENT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tmn_users_username` (`username`),
  UNIQUE KEY `uq_tmn_users_email` (`email`),
  KEY `idx_tmn_users_role_status` (`role`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_users`
--

LOCK TABLES `tmn_users` WRITE;
/*!40000 ALTER TABLE `tmn_users` DISABLE KEYS */;
INSERT INTO `tmn_users` VALUES (1,'admin.demo','$2y$10$0WfC84ipWFt5BjuRuSKqiONsM0zcvWsqyvnNJOkZuB1lQdX1CficC','admin.demo@example.test','ADMIN','ACTIVE','2026-09-03 04:09:34','2026-09-02 11:21:51','2026-09-03 09:39:34'),(2,'teacher.aisha','$2y$10$0WfC84ipWFt5BjuRuSKqiONsM0zcvWsqyvnNJOkZuB1lQdX1CficC','aisha@example.test','TEACHER','ACTIVE','2026-09-05 03:12:58','2026-09-02 11:21:51','2026-09-05 08:42:58'),(3,'teacher.rahul','$2y$10$0WfC84ipWFt5BjuRuSKqiONsM0zcvWsqyvnNJOkZuB1lQdX1CficC','rahul@example.test','TEACHER','ACTIVE',NULL,'2026-09-02 11:21:51','2026-09-02 11:21:51'),(4,'student.kavya','$2y$10$0WfC84ipWFt5BjuRuSKqiONsM0zcvWsqyvnNJOkZuB1lQdX1CficC','kavya@example.test','STUDENT','ACTIVE','2026-09-03 06:29:40','2026-09-02 11:21:51','2026-09-03 11:59:40'),(5,'student.arjun','$2y$10$0WfC84ipWFt5BjuRuSKqiONsM0zcvWsqyvnNJOkZuB1lQdX1CficC','arjun@example.test','STUDENT','ACTIVE','2026-09-04 14:45:18','2026-09-02 11:21:51','2026-09-04 20:15:18'),(6,'student.meera','$2y$10$0WfC84ipWFt5BjuRuSKqiONsM0zcvWsqyvnNJOkZuB1lQdX1CficC','meera@example.test','STUDENT','ACTIVE','2026-09-02 13:29:56','2026-09-02 11:21:51','2026-09-02 18:59:56'),(7,'student.rohan','$2y$10$0WfC84ipWFt5BjuRuSKqiONsM0zcvWsqyvnNJOkZuB1lQdX1CficC','rohan@example.test','STUDENT','ACTIVE',NULL,'2026-09-02 11:21:51','2026-09-02 11:21:51'),(12,'admin.santanu','$2y$10$1/rkOArA.xijIKmcYJ8lp.GUgbAhst9RuIBix1nUrcepanUkPbvdm','fromsantanu@gmail.com','ADMIN','ACTIVE','2026-09-04 14:39:06','2026-09-03 09:41:10','2026-09-04 20:09:06'),(14,'teacher.santanu','$2y$10$4ZtBH57RSlFpRNq7vOoJvuepEXLrTk2t299AN.tW5cPZqUoLoujhS','fromsantanuact@gmail.com','TEACHER','ACTIVE','2026-09-03 14:59:34','2026-09-03 09:45:05','2026-09-03 20:29:34');
/*!40000 ALTER TABLE `tmn_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:44
