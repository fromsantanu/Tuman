-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_invoices`
--

DROP TABLE IF EXISTS `tmn_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacher_student_id` bigint unsigned NOT NULL,
  `batch_id` bigint unsigned DEFAULT NULL,
  `batch_billing_rule_id` bigint unsigned DEFAULT NULL,
  `billing_period_from` date NOT NULL,
  `billing_period_to` date NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(12,2) NOT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `status` enum('DRAFT','ISSUED','PARTIALLY_PAID','PAID','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tmn_invoices_number` (`invoice_number`),
  KEY `idx_tmn_invoices_assignment_date` (`teacher_student_id`,`invoice_date`),
  KEY `idx_tmn_invoices_period` (`billing_period_from`,`billing_period_to`),
  KEY `idx_tmn_invoices_batch_period` (`batch_id`,`billing_period_from`,`billing_period_to`),
  KEY `idx_tmn_invoices_batch_rule_period` (`batch_billing_rule_id`,`billing_period_from`,`billing_period_to`),
  CONSTRAINT `fk_tmn_invoices_assignment` FOREIGN KEY (`teacher_student_id`) REFERENCES `tmn_teacher_students` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_invoices_batch` FOREIGN KEY (`batch_id`) REFERENCES `tmn_batches` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_invoices_batch_billing_rule` FOREIGN KEY (`batch_billing_rule_id`) REFERENCES `tmn_batch_billing_rules` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_tmn_invoices_amounts` CHECK (((`subtotal` >= 0) and (`discount_amount` >= 0) and (`total_amount` >= 0))),
  CONSTRAINT `chk_tmn_invoices_period` CHECK ((`billing_period_to` >= `billing_period_from`))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_invoices`
--

LOCK TABLES `tmn_invoices` WRITE;
/*!40000 ALTER TABLE `tmn_invoices` DISABLE KEYS */;
INSERT INTO `tmn_invoices` VALUES (1,'TMN-2026-000001',1,NULL,NULL,'2026-08-01','2026-08-31','2026-09-01','2026-09-10',3000.00,0.00,3000.00,'INR','PAID','2026-09-02 11:21:51','2026-09-03 20:32:02'),(2,'TMN-2026-000002',2,NULL,NULL,'2026-08-01','2026-08-31','2026-09-01','2026-09-10',2000.00,0.00,2000.00,'INR','PAID','2026-09-02 11:21:51','2026-09-03 15:39:16'),(7,'TMN-2026-000003',2,NULL,NULL,'2026-09-01','2026-09-30','2026-09-02',NULL,2000.00,200.00,1800.00,'INR','PAID','2026-09-02 19:42:04','2026-09-03 15:30:15'),(8,'TMN-2026-000004',2,NULL,NULL,'2026-03-01','2026-03-31','2026-09-03','2026-09-10',2000.00,0.00,2000.00,'INR','CANCELLED','2026-09-03 12:45:53','2026-09-03 12:46:41'),(9,'TMN-2026-000005',2,NULL,NULL,'2026-04-01','2026-04-30','2026-09-03','2026-09-10',2000.00,0.00,2000.00,'INR','PAID','2026-09-03 15:48:48','2026-09-03 15:58:13'),(10,'TMN-2026-000006',2,NULL,NULL,'2026-05-01','2026-05-31','2026-09-03',NULL,2000.00,0.00,2000.00,'INR','PAID','2026-09-03 15:59:10','2026-09-03 16:07:17'),(11,'TMN-2026-000007',2,2,5,'2026-09-01','2026-09-30','2026-09-05',NULL,500.00,0.00,500.00,'INR','ISSUED','2026-09-05 09:40:41','2026-09-05 09:41:09');
/*!40000 ALTER TABLE `tmn_invoices` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:44
