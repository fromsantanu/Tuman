-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_teacher_payment_details`
--

DROP TABLE IF EXISTS `tmn_teacher_payment_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_teacher_payment_details` (
  `teacher_user_id` bigint unsigned NOT NULL,
  `indian_account_holder` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indian_bank_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indian_branch` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indian_account_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indian_ifsc` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indian_upi_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indian_pan_gstin` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indian_reference_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_beneficiary` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_bank_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_bank_address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_account_iban` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_swift_bic` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_intermediary_details` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_fee_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `international_reference_note` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`teacher_user_id`),
  CONSTRAINT `fk_tmn_teacher_payment_details_teacher` FOREIGN KEY (`teacher_user_id`) REFERENCES `tmn_users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_teacher_payment_details`
--

LOCK TABLES `tmn_teacher_payment_details` WRITE;
/*!40000 ALTER TABLE `tmn_teacher_payment_details` DISABLE KEYS */;
INSERT INTO `tmn_teacher_payment_details` VALUES (2,'Alisha Patiha','HDFC','Kalyani','00124356748','KAL004HDFC','alishapatiha@okhdfcbank',NULL,'Send INR Payment here','Alisha Patiha','HDFC','Kalyani','00124356748','784935637',NULL,NULL,NULL,'2026-09-02 19:39:54','2026-09-02 19:39:54');
/*!40000 ALTER TABLE `tmn_teacher_payment_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:44
