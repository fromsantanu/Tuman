-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_student_credits`
--

DROP TABLE IF EXISTS `tmn_student_credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_student_credits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `teacher_student_id` bigint unsigned NOT NULL,
  `source_payment_id` bigint unsigned NOT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_amount` decimal(12,2) NOT NULL,
  `remaining_amount` decimal(12,2) NOT NULL,
  `status` enum('ACTIVE','EXHAUSTED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tmn_student_credits_source_payment` (`source_payment_id`),
  KEY `idx_tmn_student_credits_assignment_currency` (`teacher_student_id`,`currency_code`,`status`),
  CONSTRAINT `fk_tmn_student_credits_assignment` FOREIGN KEY (`teacher_student_id`) REFERENCES `tmn_teacher_students` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_student_credits_payment` FOREIGN KEY (`source_payment_id`) REFERENCES `tmn_payments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_tmn_student_credits_amounts` CHECK (((`original_amount` > 0) and (`remaining_amount` >= 0) and (`remaining_amount` <= `original_amount`)))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_student_credits`
--

LOCK TABLES `tmn_student_credits` WRITE;
/*!40000 ALTER TABLE `tmn_student_credits` DISABLE KEYS */;
INSERT INTO `tmn_student_credits` VALUES (1,2,2,'INR',700.00,0.00,'EXHAUSTED','2026-09-03 15:30:15','2026-09-03 15:31:59'),(2,2,4,'INR',500.00,0.00,'EXHAUSTED','2026-09-03 15:58:13','2026-09-03 16:00:46'),(3,1,6,'INR',3000.00,0.00,'EXHAUSTED','2026-09-03 20:32:02','2026-09-03 20:45:57');
/*!40000 ALTER TABLE `tmn_student_credits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:44
