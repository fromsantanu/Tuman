-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_attendance`
--

DROP TABLE IF EXISTS `tmn_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_attendance` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `teacher_student_id` bigint unsigned NOT NULL,
  `billing_rule_id` bigint unsigned DEFAULT NULL,
  `batch_id` bigint unsigned DEFAULT NULL,
  `batch_billing_rule_id` bigint unsigned DEFAULT NULL,
  `session_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `duration_minutes` smallint unsigned DEFAULT NULL,
  `status` enum('PRESENT','ABSENT','LEAVE','CANCELLED','HOLIDAY') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tmn_attendance_session` (`teacher_student_id`,`session_date`,`start_time`),
  KEY `idx_tmn_attendance_assignment_date` (`teacher_student_id`,`session_date`),
  KEY `fk_tmn_attendance_billing_rule` (`billing_rule_id`),
  KEY `idx_tmn_attendance_batch_date` (`batch_id`,`session_date`),
  KEY `fk_tmn_attendance_batch_billing_rule` (`batch_billing_rule_id`),
  CONSTRAINT `fk_tmn_attendance_assignment` FOREIGN KEY (`teacher_student_id`) REFERENCES `tmn_teacher_students` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_attendance_batch` FOREIGN KEY (`batch_id`) REFERENCES `tmn_batches` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_attendance_batch_billing_rule` FOREIGN KEY (`batch_billing_rule_id`) REFERENCES `tmn_batch_billing_rules` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_attendance_billing_rule` FOREIGN KEY (`billing_rule_id`) REFERENCES `tmn_student_billing` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_tmn_attendance_time_range` CHECK (((`end_time` is null) or (`start_time` is null) or (`end_time` > `start_time`)))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_attendance`
--

LOCK TABLES `tmn_attendance` WRITE;
/*!40000 ALTER TABLE `tmn_attendance` DISABLE KEYS */;
INSERT INTO `tmn_attendance` VALUES (1,1,NULL,NULL,NULL,'2026-08-05','16:00:00','17:00:00',60,'PRESENT','Algebra revision','2026-09-02 11:21:51','2026-09-02 11:21:51'),(2,1,NULL,NULL,NULL,'2026-08-12','16:00:00','17:30:00',90,'PRESENT','Practice problems','2026-09-02 11:21:51','2026-09-02 11:21:51'),(10,2,7,NULL,NULL,'2026-09-03','21:00:00','22:00:00',60,'PRESENT','Special class','2026-09-03 20:17:53','2026-09-03 20:17:53');
/*!40000 ALTER TABLE `tmn_attendance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:44
