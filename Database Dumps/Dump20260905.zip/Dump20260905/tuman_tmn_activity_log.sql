-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_activity_log`
--

DROP TABLE IF EXISTS `tmn_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` bigint unsigned DEFAULT NULL,
  `details_json` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tmn_activity_log_actor_created` (`actor_user_id`,`created_at`),
  KEY `idx_tmn_activity_log_entity` (`entity_type`,`entity_id`),
  CONSTRAINT `fk_tmn_activity_log_actor` FOREIGN KEY (`actor_user_id`) REFERENCES `tmn_users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_activity_log`
--

LOCK TABLES `tmn_activity_log` WRITE;
/*!40000 ALTER TABLE `tmn_activity_log` DISABLE KEYS */;
INSERT INTO `tmn_activity_log` VALUES (4,1,'USER_STATUS_CHANGED','USER',4,'{\"to\": \"INACTIVE\", \"from\": \"ACTIVE\"}','2026-09-02 11:31:30'),(5,1,'USER_STATUS_CHANGED','USER',4,'{\"to\": \"ACTIVE\", \"from\": \"INACTIVE\"}','2026-09-02 11:31:30'),(39,2,'INVOICE_CREATED','INVOICE',7,'{\"status\": \"DRAFT\", \"assignment_id\": 2, \"billing_month\": \"2026-09\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000003\"}','2026-09-02 19:42:04'),(40,1,'USER_CREATED','USER',12,'{\"role\": \"STUDENT\", \"username\": \"admin.santanu\"}','2026-09-03 09:41:10'),(41,1,'USER_UPDATED','USER',12,'{\"username\": \"admin.santanu\"}','2026-09-03 09:41:47'),(42,1,'USER_ROLE_CHANGED','USER',12,'{\"to\": \"ADMIN\", \"from\": \"STUDENT\"}','2026-09-03 09:41:47'),(43,1,'USER_CREATED','USER',14,'{\"role\": \"TEACHER\", \"username\": \"teacher.santanu\"}','2026-09-03 09:45:05'),(44,14,'STUDENT_LINKED','TEACHER_STUDENT',6,'{\"student_id\": 4}','2026-09-03 10:25:55'),(45,14,'STUDENT_LINKED','TEACHER_STUDENT',7,'{\"student_id\": 5}','2026-09-03 10:29:37'),(46,14,'PROFILE_UPDATED','USER',14,'[]','2026-09-03 11:58:36'),(47,14,'PROFILE_UPDATED','USER',14,'[]','2026-09-03 11:58:56'),(48,4,'PROFILE_UPDATED','USER',4,'[]','2026-09-03 12:04:28'),(49,4,'PROFILE_UPDATED','USER',4,'[]','2026-09-03 12:04:40'),(50,2,'INVOICE_DISCOUNT_UPDATED','INVOICE',7,'{\"currency_code\": \"INR\", \"discount_amount\": \"200.00\"}','2026-09-03 12:40:55'),(51,2,'INVOICE_ISSUED','INVOICE',7,'{\"to\": \"ISSUED\", \"invoice_number\": \"TMN-2026-000003\"}','2026-09-03 12:41:11'),(52,2,'INVOICE_CREATED','INVOICE',8,'{\"status\": \"DRAFT\", \"assignment_id\": 2, \"billing_month\": \"2026-03\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000004\"}','2026-09-03 12:45:53'),(53,2,'INVOICE_CANCELLED','INVOICE',8,'{\"to\": \"CANCELLED\", \"invoice_number\": \"TMN-2026-000004\"}','2026-09-03 12:46:41'),(54,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',7,'{\"status\": \"PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000003\"}','2026-09-03 15:30:15'),(55,2,'OVERPAYMENT_CREDIT_CREATED','STUDENT_CREDIT',1,'{\"amount\": \"700.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000003\"}','2026-09-03 15:30:15'),(56,2,'PAYMENT_RECORDED','PAYMENT',2,'{\"amount\": \"2500.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000003\", \"invoice_status\": \"PAID\", \"payment_method\": \"CASH\"}','2026-09-03 15:30:15'),(57,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',2,'{\"status\": \"PARTIALLY_PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000002\"}','2026-09-03 15:31:59'),(58,2,'CREDIT_APPLIED','STUDENT_CREDIT',1,'{\"amount\": \"700.00\", \"invoice_id\": 2, \"currency_code\": \"INR\"}','2026-09-03 15:31:59'),(59,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',2,'{\"status\": \"PARTIALLY_PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000002\"}','2026-09-03 15:33:37'),(60,2,'PAYMENT_RECORDED','PAYMENT',3,'{\"amount\": \"1300.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000002\", \"invoice_status\": \"PARTIALLY_PAID\", \"payment_method\": \"CASH\"}','2026-09-03 15:33:37'),(61,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',2,'{\"status\": \"PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000002\"}','2026-09-03 15:39:16'),(62,2,'INVOICE_CREATED','INVOICE',9,'{\"status\": \"DRAFT\", \"assignment_id\": 2, \"billing_month\": \"2026-04\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000005\"}','2026-09-03 15:48:48'),(63,2,'INVOICE_ISSUED','INVOICE',9,'{\"to\": \"ISSUED\", \"invoice_number\": \"TMN-2026-000005\"}','2026-09-03 15:52:02'),(64,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',9,'{\"status\": \"PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000005\"}','2026-09-03 15:58:13'),(65,2,'OVERPAYMENT_CREDIT_CREATED','STUDENT_CREDIT',2,'{\"amount\": \"500.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000005\"}','2026-09-03 15:58:13'),(66,2,'PAYMENT_RECORDED','PAYMENT',4,'{\"amount\": \"2500.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000005\", \"invoice_status\": \"PAID\", \"payment_method\": \"CASH\"}','2026-09-03 15:58:13'),(67,2,'INVOICE_CREATED','INVOICE',10,'{\"status\": \"DRAFT\", \"assignment_id\": 2, \"billing_month\": \"2026-05\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000006\"}','2026-09-03 15:59:10'),(68,2,'INVOICE_ISSUED','INVOICE',10,'{\"to\": \"ISSUED\", \"invoice_number\": \"TMN-2026-000006\"}','2026-09-03 15:59:28'),(69,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',10,'{\"status\": \"PARTIALLY_PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000006\"}','2026-09-03 16:00:46'),(70,2,'CREDIT_APPLIED','STUDENT_CREDIT',2,'{\"amount\": \"500.00\", \"invoice_id\": 10, \"currency_code\": \"INR\"}','2026-09-03 16:00:46'),(71,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',10,'{\"status\": \"PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000006\"}','2026-09-03 16:07:17'),(72,2,'PAYMENT_RECORDED','PAYMENT',5,'{\"amount\": \"1500.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000006\", \"invoice_status\": \"PAID\", \"payment_method\": \"CASH\"}','2026-09-03 16:07:17'),(73,2,'BILLING_RULE_CREATED','STUDENT_BILLING',7,'{\"billing_mode\": \"HOURLY\", \"currency_code\": \"INR\"}','2026-09-03 20:12:23'),(74,2,'ATTENDANCE_CREATED','ATTENDANCE',10,'{\"status\": \"PRESENT\", \"assignment_id\": 2}','2026-09-03 20:17:53'),(75,2,'INVOICE_PAYMENT_STATUS_CHANGED','INVOICE',1,'{\"status\": \"PAID\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000001\"}','2026-09-03 20:32:02'),(76,2,'OVERPAYMENT_CREDIT_CREATED','STUDENT_CREDIT',3,'{\"amount\": \"3000.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000001\"}','2026-09-03 20:32:02'),(77,2,'PAYMENT_RECORDED','PAYMENT',6,'{\"amount\": \"4500.00\", \"currency_code\": \"INR\", \"invoice_number\": \"TMN-2026-000001\", \"invoice_status\": \"PAID\", \"payment_method\": \"CASH\"}','2026-09-03 20:32:02'),(78,2,'ADJUSTMENT_REFUND_RECORDED','REFUND',1,'{\"amount\": \"500.00\", \"reason\": \"Arbitrari\", \"currency_code\": \"INR\"}','2026-09-03 20:43:36'),(79,2,'CREDIT_REFUNDED','REFUND',2,'{\"amount\": \"3000.00\", \"reason\": \"Extra payment refunded\", \"credit_id\": 3, \"currency_code\": \"INR\"}','2026-09-03 20:45:57'),(83,2,'BATCH_CREATED','BATCH',2,'{\"billing_mode\": \"FIXED_MONTHLY\", \"currency_code\": \"INR\"}','2026-09-05 08:45:51'),(84,2,'BATCH_MEMBER_ADDED','BATCH',2,'{\"assignment_id\": 2}','2026-09-05 08:46:41'),(91,2,'BATCH_BILLING_RULE_CREATED','BATCH',2,'{\"billing_mode\": \"INSTALLMENTS\"}','2026-09-05 09:05:15'),(92,2,'BATCH_BILLING_RULE_CREATED','BATCH',2,'{\"rule_code\": \"INST-1\", \"billing_mode\": \"INSTALLMENTS\"}','2026-09-05 09:12:32'),(93,2,'BATCH_INVOICE_CREATED','INVOICE',11,'{\"batch_id\": 2, \"rule_code\": \"INST-1\"}','2026-09-05 09:40:41'),(94,2,'INVOICE_ISSUED','INVOICE',11,'{\"to\": \"ISSUED\", \"invoice_number\": \"TMN-2026-000007\"}','2026-09-05 09:41:09');
/*!40000 ALTER TABLE `tmn_activity_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:44
