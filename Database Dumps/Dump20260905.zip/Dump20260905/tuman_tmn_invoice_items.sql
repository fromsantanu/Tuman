-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_invoice_items`
--

DROP TABLE IF EXISTS `tmn_invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_invoice_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint unsigned NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit_rate` decimal(12,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `sort_order` smallint unsigned NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tmn_invoice_items_invoice_sort` (`invoice_id`,`sort_order`),
  CONSTRAINT `fk_tmn_invoice_items_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `tmn_invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_tmn_invoice_items_values` CHECK (((`quantity` > 0) and (`unit_rate` >= 0) and (`amount` >= 0)))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_invoice_items`
--

LOCK TABLES `tmn_invoice_items` WRITE;
/*!40000 ALTER TABLE `tmn_invoice_items` DISABLE KEYS */;
INSERT INTO `tmn_invoice_items` VALUES (1,1,'Tuition — 10 hours',10.00,300.00,3000.00,1,'2026-09-02 11:21:51'),(2,2,'Monthly tuition fee',1.00,2000.00,2000.00,1,'2026-09-02 11:21:51'),(8,7,'Monthly tuition — September 2026',1.00,2000.00,2000.00,1,'2026-09-02 19:42:04'),(9,8,'Monthly tuition — March 2026',1.00,2000.00,2000.00,1,'2026-09-03 12:45:53'),(10,9,'Monthly tuition — April 2026',1.00,2000.00,2000.00,1,'2026-09-03 15:48:48'),(11,10,'Monthly tuition — May 2026',1.00,2000.00,2000.00,1,'2026-09-03 15:59:10'),(12,11,'First instalment (INST-1) — Batch 1 — 2026-09',1.00,500.00,500.00,1,'2026-09-05 09:40:41');
/*!40000 ALTER TABLE `tmn_invoice_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:43
