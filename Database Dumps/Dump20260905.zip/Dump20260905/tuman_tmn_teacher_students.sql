-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_teacher_students`
--

DROP TABLE IF EXISTS `tmn_teacher_students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_teacher_students` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `teacher_user_id` bigint unsigned NOT NULL,
  `student_user_id` bigint unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tmn_teacher_students_pair` (`teacher_user_id`,`student_user_id`),
  KEY `idx_tmn_teacher_students_teacher_status` (`teacher_user_id`,`status`),
  KEY `idx_tmn_teacher_students_student_status` (`student_user_id`,`status`),
  CONSTRAINT `fk_tmn_teacher_students_student` FOREIGN KEY (`student_user_id`) REFERENCES `tmn_users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_teacher_students_teacher` FOREIGN KEY (`teacher_user_id`) REFERENCES `tmn_users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_tmn_teacher_students_dates` CHECK (((`end_date` is null) or (`end_date` >= `start_date`)))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_teacher_students`
--

LOCK TABLES `tmn_teacher_students` WRITE;
/*!40000 ALTER TABLE `tmn_teacher_students` DISABLE KEYS */;
INSERT INTO `tmn_teacher_students` VALUES (1,2,4,'2026-01-01',NULL,'ACTIVE','2026-09-02 11:21:51','2026-09-02 11:21:51'),(2,2,5,'2026-01-01',NULL,'ACTIVE','2026-09-02 11:21:51','2026-09-02 11:21:51'),(3,3,6,'2026-01-01',NULL,'ACTIVE','2026-09-02 11:21:51','2026-09-02 11:21:51'),(4,3,7,'2026-01-01',NULL,'ACTIVE','2026-09-02 11:21:51','2026-09-02 11:21:51'),(6,14,4,'2026-09-03',NULL,'ACTIVE','2026-09-03 10:25:55','2026-09-03 10:25:55'),(7,14,5,'2026-09-03',NULL,'ACTIVE','2026-09-03 10:29:37','2026-09-03 10:29:37');
/*!40000 ALTER TABLE `tmn_teacher_students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:45
