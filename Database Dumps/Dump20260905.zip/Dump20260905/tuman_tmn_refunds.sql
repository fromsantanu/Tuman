-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tuman
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tmn_refunds`
--

DROP TABLE IF EXISTS `tmn_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tmn_refunds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `teacher_student_id` bigint unsigned NOT NULL,
  `invoice_id` bigint unsigned DEFAULT NULL,
  `payment_id` bigint unsigned DEFAULT NULL,
  `credit_id` bigint unsigned DEFAULT NULL,
  `refund_type` enum('PAYMENT','CREDIT','ADJUSTMENT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `refund_date` date NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `refund_method` enum('CASH','UPI','BANK_TRANSFER','CARD','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tmn_refunds_assignment_date` (`teacher_student_id`,`refund_date`),
  KEY `idx_tmn_refunds_payment` (`payment_id`),
  KEY `idx_tmn_refunds_credit` (`credit_id`),
  KEY `idx_tmn_refunds_invoice` (`invoice_id`),
  CONSTRAINT `fk_tmn_refunds_assignment` FOREIGN KEY (`teacher_student_id`) REFERENCES `tmn_teacher_students` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_refunds_credit` FOREIGN KEY (`credit_id`) REFERENCES `tmn_student_credits` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_refunds_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `tmn_invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_tmn_refunds_payment` FOREIGN KEY (`payment_id`) REFERENCES `tmn_payments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `chk_tmn_refunds_amount` CHECK ((`amount` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmn_refunds`
--

LOCK TABLES `tmn_refunds` WRITE;
/*!40000 ALTER TABLE `tmn_refunds` DISABLE KEYS */;
INSERT INTO `tmn_refunds` VALUES (1,1,NULL,NULL,NULL,'ADJUSTMENT','2026-09-03',500.00,'INR','OTHER','R-500','Arbitrari','2026-09-03 20:43:36'),(2,1,NULL,NULL,3,'CREDIT','2026-09-03',3000.00,'INR','BANK_TRANSFER','Extra payment refunded','Extra payment refunded','2026-09-03 20:45:57');
/*!40000 ALTER TABLE `tmn_refunds` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05 10:06:43
